/*
Navicat MySQL Data Transfer

Source Server         : 生产169
Source Server Version : 50722
Source Host           : 139.224.128.169:3309
Source Database       : zx_risk

Target Server Type    : MYSQL
Target Server Version : 50722
File Encoding         : 65001

Date: 2018-11-15 16:27:08
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for risk_decision_rule
-- ----------------------------
DROP TABLE IF EXISTS `risk_decision_rule`;
CREATE TABLE `risk_decision_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL COMMENT '名称',
  `category` varchar(32) NOT NULL COMMENT '规则分类',
  `description` varchar(200) NOT NULL COMMENT '规则描述',
  `enabled` tinyint(4) NOT NULL COMMENT '是否可用，1-是',
  `priority` int(11) NOT NULL DEFAULT '500' COMMENT '执行优先级，值大的优先执行',
  `handler` varchar(512) NOT NULL COMMENT '执行方法，格式:$package.class.method',
  `reject_reason_code` varchar(32) NOT NULL COMMENT '拒绝原因编码',
  `setting` varchar(1024) NOT NULL COMMENT '规则配置，json字符串',
  `add_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '添加用户ID',
  `add_user` bigint(20) NOT NULL DEFAULT '0' COMMENT '添加人user_id',
  `update_time` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新时间',
  `update_user` bigint(20) NOT NULL DEFAULT '0' COMMENT '更新用户ID',
  `max_suspend_timeout` bigint(20) NOT NULL DEFAULT '0' COMMENT '最大挂起时长(距离本规则首次执行,秒)',
  `max_suspend_cnt` int(11) NOT NULL DEFAULT '0' COMMENT '最大挂起次数',
  `suspend_result` tinyint(4) NOT NULL DEFAULT '3' COMMENT '规则挂起次数过多或超时后返回的结果状态（参考miaobt_decision_admission_result.result）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1062 DEFAULT CHARSET=utf8 COMMENT='准入规则';

-- ----------------------------
-- Records of risk_decision_rule
-- ----------------------------
INSERT INTO `risk_decision_rule` VALUES ('1001', '决策通过', '1', '1', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.approved', '', '', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1002', '决策拒绝', '1', '1', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.rejected', 'R1819', '', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1004', '设备是否多人使用', '17', '验证申请人设备是否多人使用', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyDevice', 'R304', '{\"maxCount\":\"3\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1011', '黑名单-手机号', '13', '验证申请人手机号是否在黑名单内', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyPhoneBlackList', 'R402', '', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1012', '黑名单-身份证号', '13', '验证申请人身份证号是否在黑名单内', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyIdCardBlackList', 'R401', '', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1013', '验证年龄-小', '8', '验证客户年龄是否低于指定年龄', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyMinAge', 'R103', '{\"minAge\":\"18\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1014', '验证年龄-大', '8', '验证申请人是否超龄', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyMaxAge', 'R103', '{\"maxAge\":\"50\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1015', '设备通话记录验证黑名单', '26', '验证申请人设备通话记录是否包含黑名单号码', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifydevCallRecord', 'R701', '{\"MinCount\":\"5\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1016', '短信验证-黑名单', '27', '验证短信中是否包含黑名单客户', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifySMS', 'R801', '{\"MinCount\":\"1\"}', '1520056384400', '0', '1520056384400', '0', '7200', '1', '1');
INSERT INTO `risk_decision_rule` VALUES ('1017', '通讯录验证-黑名单', '25', '验证申请人通讯录中是否包含黑名单客户', '1', '400', 'com.risk.controller.service.handler.VerifyHandler.verifyContact', 'R602', '{\"MinCount\":\"4\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1018', '检查申请人使用设备的个数', '0', '检查申请人使用的设备个数(每类设备的最大个数)是否超过标准', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyDeviceCount', 'R310', '{\"maxDevices\":\"4\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1019', '通讯录验证-严重敏感词', '25', '验证申请人通讯录里包含严重敏感词', '1', '400', 'com.risk.controller.service.handler.VerifyHandler.verifyContactKeyWord', 'R604', '{\"SensitiveWord\":\"高炮,借条,黑户,白户,高利贷,空放\",\"SensitiveWordCount\":\"1\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1020', '短信验证-严重敏感词', '27', '验证申请人短信中是否包含严重敏感词', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifySMSKeyWord', 'R803', '{\"KeyWord\":\"法催部,严重逾期,恶意透支,逃避欠款,逃避还款,催收录音,大耳窿,涉嫌违法,婊子,起诉,委外,吸毒,贩毒,抽大烟,麻古,麻果,k粉,冰妹,赌徒,赌输\",\"KeyWordCount\":\"1\",\"days\":\"60\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1021', '短信验证-一般敏感词', '27', '验证申请人短信中是否包含一般敏感词', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifySMSSensitiveWord', 'R804', '{\"SensitiveWord\":\"欠款,欠债,拖欠,已逾期,已经逾期,过不下去,活不下去,输完,输光,飞叶子,溜冰,上门催收,滞纳金,逾期未还,还钱,扣款失败,合同超期,已发生逾期,多次提醒仍未还款,严重超期\",\"SensitiveWordCount\":\"6\",\"NotSensitiveWord\":\"交警,电费,水费,水电费,物业费,如已还款,若已还款,已结清\",\"days\":\"60\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1022', '短信验证-风险识别', '0', '短信风险识别', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.checkRiskSMS', 'R803', '{\"failFast\":\"1\",\"blacklistSource\":\"yhb_risk_sms\",\"blacklistLevel\":\"3\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1023', '通讯录中注册用户检查', '25', '检查用户通讯录中是否有其它注册用户', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyContactIsRegister', 'R609', '{\"warningCount\":\"5\",\"dangerCount\":\"5\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1024', '通讯录中联系人数量验证', '25', '检查通讯录中联系人的数量', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyContactNum', 'R606', '{\"minCount\":\"20\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1026', '手机号码实名认证', '37', '验证用户注册手机号码是否在运营商实名', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyJuXinLiIsRealName', 'R1101', '', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1027', '设备有效通讯录黑名单验证', '26', '用户与设备通讯录通话过(运营商通话)的手机号码进行黑名单验证', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyjxlCallRecord', 'R711', '{\"MinCount\":\"2\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1031', '手机号码使用时间', '37', '>5个月通过，否则不通过', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyMobildIsNew', 'R1102', '{\"minCount\":\"6\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1032', '身份证地区黑名单验证', '9', '身份证地区黑名单验证', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyAreaIdCardBlackList', 'R201', '', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1033', '紧急联系人是否与注册号码一致', '36', '验证紧急联系人号码是否与注册号码一致，且是11位', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyEmergencyContact', 'R1001', '', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1034', '紧急联系人黑名单', '36', '紧急联系人是否存在黑名单', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyContactBlackList', 'R501', '', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1035', '紧急联系人通话次数', '59', '紧急联系人通常次数大于20次', '1', '400', 'com.risk.controller.service.handler.VerifyHandler.verifyMainContactCallCount', 'R1004', '{\"callCount\":\"20\",\"callTime\":\"2000\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1036', '紧急联系人通话时长', '36', '紧急联系人通常次数大于2000秒', '0', '400', 'com.risk.controller.service.handler.VerifyHandler.verifyMainContactCallTime', 'R1002', '{\"callTime\":\"2000\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1037', '短号验证，保存通话记录', '38', '短号超过3个拒绝，>=3拒绝，命中110拒绝', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyShortNoAll', 'R608', '{\"minCount\":\"6\",\"shortNos\":\"110,114,112,117,120,119,122,121,103,108,184,999\",\"count110\":\"2\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1038', '黑名单-idfa', '13', '命中不通过', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyIdfaBlackList', 'R403', '', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1039', '黑名单-mac', '13', '命中不通过', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyMacBlackList', 'R403', '', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1040', '黑名单-imei', '13', '命中不通过', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyImeiBlackList', 'R403', '', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1042', '新颜贷款逾期订单数', '53', '新颜贷款逾期订单数 <=5通过，其他拒绝', '1', '500', 'com.risk.controller.service.handler.XinyanHandler.verifyXinyanData', 'R1819', '{\"minCount\":\"5\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1043', '新颜申请雷达分数', '53', '新颜申请雷达分数', '0', '500', 'com.risk.controller.service.handler.XinyanHandler.verifyXinyanApplyData', 'R3001', '{\"minScore\":\"500\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1044', '新颜行为雷达分数', '53', '新颜行为雷达分数', '0', '500', 'com.risk.controller.service.handler.XinyanHandler.verifyXinyanBehaviorData', 'R3002', '{\"minScore\":\"500\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1045', '树美多头借贷', '54', '树美多头借贷7天的>=5拒绝', '1', '700', 'com.risk.controller.service.handler.ShuMeiHandler.verifyShumeiData', 'R4001', '{\"minCount\":\"5\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1046', '运营商话费验证', '55', '抓取月份>5,并且平均话费>=4500分,且每个月小于40000分', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyUserCharge', 'R5001', '{\"avgCharge\":\"2000\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1047', '用户手机连号验证', '56', '3连号以上的拒绝', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyPhoneContinuous', 'R328', '{\"length\":\"4\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1048', '民族验证', '58', '民族命中拒绝', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyUserNation', 'R329', '{\"keys\":\"回,畲,壮,藏,维吾尔,满\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '1');
INSERT INTO `risk_decision_rule` VALUES ('1049', '排序模型', '59', '排序模型结构', '1', '500', 'com.risk.controller.service.handler.PaixuHandler.verifyPaixuDecision', 'R1821', '{\"checkScore\":\"490\",\"passScore\":\"580\",\"excludeScore\":\"-1\",\"passPercent\":\"0.34\",\"passCount\":\"0\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1050', '通讯录与运营商通通话次数校验', '50', 'android>=15,ios>20', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyOpertorCount', 'R1822', '{\"android\":\"20\",\"ios\":\"20\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1051', '树美在多个不同网贷平台被拒绝', '50', '>=2个平台贷款被拒拒绝', '1', '650', 'com.risk.controller.service.handler.ShuMeiHandler.verifyShumeiReject', 'R1823', '{\"minCount\":\"2\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1052', '用户、紧急联系人手机号码空号、羊毛党验证', '50', '验证是否是空号，羊毛党', '0', '600', 'com.risk.controller.service.handler.VerifyHandler.verifyPhone', 'R1824', '', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1053', '用户设备通讯录姓名数字校验', '50', '3-6位数字的拒掉', '0', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyUserContactName', 'R1825', '{\"nameKey\":\"[0-9]{1,6}\",\"maxCount\":\"6\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1054', '10天通讯录通话10次，30天运营商通话100次', '50', '计算用户运营商信息', '1', '600', 'com.risk.controller.service.handler.ModelHandler.verifyUserOperator', 'R1826', '{\"minPercent\":\"1\",\"maxPercent\":\"1.6\",\"minTimePercent\":\"0.5\",\"maxTimePercent\":\"0.6\",\"allCallNum30\":\"100\",\"cntCallNum30\":\"10\",\"num30Compare180\":\"0.1\",\"time30Compare180\":\"0.1\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1055', '30天内通讯录5人，且2次以上有效通话', '50', '30天内，有效通话人数，次数', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyOperatorCallNumAndPeopleNum', 'R1828', '{\"days\":\"30\",\"callNum\":\"2\",\"peopleNum\":\"5\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1056', '树美多头借贷3次以上校验', '50', '3次以上通过', '0', '500', 'com.risk.controller.service.handler.ShuMeiHandler.verifyShumeApply', 'R1829', '{\"minCount\":\"3\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1057', '模型', '50', '', '1', '550', 'com.risk.controller.service.handler.RobotHandler.verifyRobot', 'R1830', '{\"passPercent\":\"0.31\",\"passCount\":\"14\",\"randomNum\":\"0\",\"passScore\":\"0\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1058', '运营商通讯录7天互相通话记录验证', '50', '7天1一次以上互相通话通过', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyCallsEach', 'R1831', '{\"callNum\":\"0\",\"callDay\":\"7\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1059', '通讯录重复联系人校验', '50', '3次三个联系人重复', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verifyRepeatContactPhone', 'R1832', '{\"repeatPerson\":\"3\",\"repeatNum\":\"3\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1060', '运营商通话次数-老户', '50', '新户30天内有效通话10次，运营商通话100次，老户：7天内有通话', '1', '500', 'com.risk.controller.service.handler.VerifyHandler.verify30DaysCallDetail', 'R1833', '{\"oldDays\": \"7\",\"oldPassNum\":\"1\",\"newDays\": \"30\",\"newCntPassNum\": \"10\",\"newAllPassNum\":\"100\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
INSERT INTO `risk_decision_rule` VALUES ('1061', '验证历史最大逾期天数', '50', '验证历史最大逾期天数', '1', '550', 'com.risk.controller.service.handler.VerifyHandler.verifyMaxOverdueDay', 'R1834', '{\"maxOverdueDay\":\"5\"}', '1520056384400', '0', '1520056384400', '0', '7200', '5', '2');
